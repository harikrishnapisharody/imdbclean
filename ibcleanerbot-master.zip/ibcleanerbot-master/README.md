This is a simple bot to Delete User Messages based on Groupmembers Votes.

# install

create a new config.py that extends sampleconfig.py and insert bot Token

```
python3 -m venv ibcenv
. /ibcenv/bin/activate
pip install -r requirement.txt
python bot.py
```

